<?php
   
    $myconn = mysqli_connect('127.0.0.1', 'root', '', 'smit') or die("Error");

    if (isset($_POST['login'])) {

        $email = $_POST['email'];
        $password = $_POST['password'];

        $select1 = "Select * from user Where username='$email'";
        $result = mysqli_query($myconn, $select1);
        $data = mysqli_fetch_array($result);

        if (isset($data)) {
            if ($_POST['password'] == $data['password']) {
                echo "<script type='text/javascript'>alert('login successfully');</script>";
            } else {
                echo "<script type='text/javascript'>alert('Worng Email or Password');</script>";
            }
            unset($data);
        }else{
            echo "<script type='text/javascript'>alert('User not found');</script>";
            unset($data);
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
      integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
      integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="styles-login.css">
<link rel="stylesheet" href="style.css">

<link href="https://fonts.googleapis.com/css2?family=Acme&display=swap" rel="stylesheet">


<title>LoginPage</title>
</head>
<body>



<!-- login form -->
<section>

<div class="container   text-center " style="background-color: #f4f4f4; border-radius: 25px;">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6 color-style p-5 rounded-1 ">
            <h2>Quick Login</h2>
            <p>Login Your Account</p>
            <form class="pt-5" method="post">
                <div class="row">
                    <div class="col-sm-12">
                        <input type="text" name="email" class="form-control col-form-label-lg" placeholder="Email">
                    </div>
                    <div class="col-sm-12 pt-4">
                        <input type="password" name="password" class="form-control col-form-label-lg"
                               placeholder="Password">
                    </div>
                    
                    <div class="col-sm-12 pt-4">
                        <input type="submit" name="login" value="Login" class="form-control btn btn-success
                col-form-label-lg
                btn-lg">
                    </div>
                    <div class="col-sm-12 pt-5">
                        <p class="h4">Don't have an account yet?</p>
                        <span class="text-dark"><b class="h5 text-dark"> <a href="register.php" class="text-dark">Register Here</a></span>
                    </div>




                </div>
            </form>
        </div>

    </div>
</div>

</section>

</body>
</html>
